﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MVCBasketball.Models;

namespace MVCBasketball.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
            //return Content("This is the default action ");
        }

        

        //GET: /Home/Welcome (without parameters)
        //GET: /Home/Welcome?playername=Kyle Lowry&age=32
        public IActionResult Welcome(string playername,int age=2)
        {
            //The ViewData dictionary is a dynamic object, 
            //which means any type can be used; 
            //the ViewData object has no defined properties 
            //until you put something inside it.
            //The MVC model binding system automatically maps 
            //the named parameters(playername and age) from the query string 
            //in the address bar to parameters in your method.             

            ViewData["Message"] = "Hello " + playername;
            ViewData["Age"] = age;

            //The ViewData dictionary object contains data that will be passed 
            //to the view.
            return View();

        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
